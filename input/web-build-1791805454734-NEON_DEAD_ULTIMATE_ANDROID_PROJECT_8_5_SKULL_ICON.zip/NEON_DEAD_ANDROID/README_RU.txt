NEON DEAD ULTIMATE 8.4 — Android-проект

Это проект Android-приложения, которое открывает HTML-игру локально внутри WebView.
Игра находится в app/src/main/assets/index.html. Интернет для самой игры не требуется.

Как собрать APK:
1. Установи Android Studio на компьютер.
2. Распакуй архив в отдельную папку.
3. В Android Studio выбери Open и укажи папку NEON_DEAD_ANDROID.
4. Дождись завершения Gradle Sync и установки Android SDK Platform 35, если Android Studio попросит.
5. Выбери Build > Build Bundle(s) / APK(s) > Build APK(s).
6. После сборки нажми locate в уведомлении. APK обычно будет в app/build/outputs/apk/debug/app-debug.apk.
7. Перенеси APK на Android-телефон и открой его. Если появится запрос, разреши установку приложений из этого источника.

Настройки: приложение открывается в горизонтальной ориентации и полноэкранном режиме.
Пакет приложения: com.neondead.ultimate
Версия: 8.4

Важно: в текущей среде Android SDK/Gradle не установлены, поэтому готовый бинарный APK здесь не собран. Архив содержит исходный Android-проект для сборки в Android Studio.


UPDATE 8.5: launcher icon changed to the black-red skull NEON DEAD ULTIMATE artwork. Rebuild the APK in AndroidForge to apply the new icon.
