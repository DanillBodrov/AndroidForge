NEON DEAD ULTIMATE — Android Forge package

Main game file: index.html

Import this ZIP into Android Forge as a web/HTML project and build the APK there.
The game is a standalone HTML file; its offline leaderboard is stored locally on each device.
Offline rankings do not automatically sync between different devices without a server.
