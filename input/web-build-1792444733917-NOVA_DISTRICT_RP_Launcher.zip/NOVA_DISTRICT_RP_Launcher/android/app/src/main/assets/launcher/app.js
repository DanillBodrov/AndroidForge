const $=id=>document.getElementById(id);
let selectedServer=1;
let toastTimer;
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2800)}
function modal(title,text,action='ПОНЯТНО'){ $('modalTitle').textContent=title;$('modalText').textContent=text;$('modalAction').textContent=action;$('progressBar').style.width='0%';$('modal').classList.add('open')}
function closeModal(){$('modal').classList.remove('open')}
$('modalClose').addEventListener('click',closeModal);$('modalAction').addEventListener('click',closeModal);
$('modal').addEventListener('click',e=>{if(e.target===$('modal'))closeModal()});
document.querySelectorAll('.server-card').forEach(card=>card.addEventListener('click',()=>{document.querySelectorAll('.server-card').forEach(c=>c.classList.remove('selected'));card.classList.add('selected');selectedServer=Number(card.dataset.server);toast('Выбран сервер: '+card.querySelector('.server-info b').textContent)}));
$('playBtn').addEventListener('click',()=>modal('КЛИЕНТ НЕ ПОДКЛЮЧЁН','Интерфейс лаунчера готов, но игровой клиент ещё не подключён. Чтобы кнопка запускала игру, добавьте официальный файл клиента и способ запуска для вашей платформы.'));
$('updatesBtn').addEventListener('click',()=>{modal('ПРОВЕРКА ОБНОВЛЕНИЙ','Проверка интерфейса завершена. Сервер обновлений пока не настроен — добавьте HTTPS-ссылку на манифест версии и файлы клиента.');$('progressBar').style.width='100%'});
$('settingsTop').addEventListener('click',()=>$('settingsPanel').scrollIntoView({behavior:'smooth',block:'center'}));
$('saveSettings').addEventListener('click',()=>{const s={animations:$('animations').checked,compact:$('compact').checked,notifications:$('notifications').checked};try{localStorage.setItem('novaLauncherSettings',JSON.stringify(s))}catch(e){}document.body.classList.toggle('compact-mode',s.compact);document.body.classList.toggle('no-animations',!s.animations);toast('Настройки сохранены на этом устройстве')});
$('communityLink').addEventListener('click',e=>{e.preventDefault();toast('Добавьте ссылку на официальное сообщество в app.js')});
try{const s=JSON.parse(localStorage.getItem('novaLauncherSettings')||'null');if(s){$('animations').checked=s.animations;$('compact').checked=s.compact;$('notifications').checked=s.notifications;document.body.classList.toggle('compact-mode',s.compact);document.body.classList.toggle('no-animations',!s.animations)}}catch(e){}
if(location.protocol==='file:')$('platform').textContent='LOCAL PREVIEW';
