package com.example.projectlauncher

import android.content.Context
import android.content.Intent

/**
 * Replace this placeholder with the documented launch method for YOUR game.
 *
 * Android apps generally cannot launch another app's private activity arbitrarily.
 * If your game is installed as a separate Android package, use its package name and
 * a supported exported launcher activity/deep link. Do not attempt to bypass another
 * game's security or access private data.
 */
object GameLauncher {
    sealed interface Result {
        data object Started : Result
        data object NotInstalled : Result
        data class Failed(val reason: String) : Result
    }

    fun launchInstalledGame(context: Context, packageName: String): Result {
        val intent: Intent? = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent == null) return Result.NotInstalled

        return try {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            Result.Started
        } catch (e: Exception) {
            Result.Failed(e.message ?: "Не удалось запустить игру")
        }
    }
}
