package com.example.projectlauncher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Background = Color(0xFF090B10)
private val Panel = Color(0xFF151923)
private val Accent = Color(0xFF7C5CFF)
private val Cyan = Color(0xFF42D9C8)
private val TextMain = Color(0xFFF4F5FA)
private val TextMuted = Color(0xFF9AA3B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    secondary = Cyan,
                    background = Background,
                    surface = Panel,
                    onBackground = TextMain,
                    onSurface = TextMain
                )
            ) {
                LauncherApp(
                    onOpenUrl = { url ->
                        runCatching {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }
                    }
                )
            }
        }
    }
}

@Composable
private fun LauncherApp(onOpenUrl: (String) -> Unit) {
    var page by remember { mutableStateOf("Главная") }
    var showLogin by remember { mutableStateOf(false) }
    var username by remember { mutableStateOf("") }
    var loggedIn by remember { mutableStateOf(false) }
    var launchMessage by remember { mutableStateOf("") }
    var updateProgress by remember { mutableFloatStateOf(0f) }
    var updating by remember { mutableStateOf(false) }
    var showLoading by remember { mutableStateOf(false) }
    var music by remember { mutableStateOf(false) }
    var highGraphics by remember { mutableStateOf(true) }
    var notifications by remember { mutableStateOf(true) }

    LaunchedEffect(showLoading) {
        if (showLoading) {
            delay(1600)
            showLoading = false
        }
    }

    Box(Modifier.fillMaxSize().background(Background)) {
        Column(Modifier.fillMaxSize()) {
            Header(
                username = if (loggedIn) username else null,
                onProfile = { showLogin = true }
            )
            if (showLoading) {
                LoadingScreen()
            } else {
                when (page) {
                    "Главная" -> HomePage(
                        username = if (loggedIn) username else null,
                        onPlay = {
                            // Replace this placeholder with your game's supported launch integration.
                            launchMessage = "Подключи запуск своей игры в GameLauncher.kt"
                        },
                        onUpdates = { page = "Обновления" },
                        onNews = { page = "Новости" },
                        launchMessage = launchMessage,
                        onDismissMessage = { launchMessage = "" }
                    )
                    "Новости" -> NewsPage()
                    "Обновления" -> UpdatesPage(
                        progress = updateProgress,
                        updating = updating,
                        onUpdate = {
                            if (!updating) {
                                updating = true
                                updateProgress = 0f
                            }
                        }
                    )
                    "Настройки" -> SettingsPage(
                        music = music, onMusic = { music = it },
                        highGraphics = highGraphics, onGraphics = { highGraphics = it },
                        notifications = notifications, onNotifications = { notifications = it }
                    )
                }
            }
            Spacer(Modifier.weight(1f))
            BottomBar(selected = page, onSelect = { page = it })
        }

        if (showLogin) {
            LoginDialog(
                username = username,
                onUsername = { username = it },
                onDismiss = { showLogin = false },
                onLogin = {
                    // Demo-only local session. Use a secure backend for real accounts.
                    loggedIn = username.trim().isNotEmpty()
                    showLogin = false
                }
            )
        }
    }

    LaunchedEffect(updating) {
        if (updating) {
            while (updateProgress < 1f) {
                delay(90)
                updateProgress = (updateProgress + 0.025f).coerceAtMost(1f)
            }
            updating = false
        }
    }
}

@Composable
private fun Header(username: String?, onProfile: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF0D1018)).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(14.dp))
                .background(Brush.linearGradient(listOf(Accent, Cyan))),
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.White, modifier = Modifier.size(27.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("NOVA", fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
            Text("ROLEPLAY", fontSize = 10.sp, color = Cyan, letterSpacing = 3.sp)
        }
        Surface(
            color = Panel,
            shape = CircleShape,
            modifier = Modifier.size(42.dp).clickable { onProfile() }
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Person, contentDescription = "Профиль", tint = TextMain)
            }
        }
    }
}

@Composable
private fun ColumnScope.HomePage(
    username: String?,
    onPlay: () -> Unit,
    onUpdates: () -> Unit,
    onNews: () -> Unit,
    launchMessage: String,
    onDismissMessage: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxWidth().weight(1f),
        contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                Modifier.fillMaxWidth().height(205.dp).clip(RoundedCornerShape(26.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF282050), Color(0xFF151B2B), Color(0xFF0E3439))))
                    .padding(22.dp)
            ) {
                Column(Modifier.align(Alignment.CenterStart)) {
                    Surface(color = Cyan.copy(alpha = .15f), shape = RoundedCornerShape(50)) {
                        Text("НОВЫЙ СЕЗОН", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("ТВОЯ ИСТОРИЯ.\nТВОИ ПРАВИЛА.", fontSize = 24.sp, lineHeight = 29.sp,
                        fontWeight = FontWeight.Black, color = TextMain)
                    Spacer(Modifier.height(8.dp))
                    Text("Добро пожаловать в NOVA RP", fontSize = 12.sp, color = TextMuted)
                }
                Icon(Icons.Default.Public, contentDescription = null, tint = Color.White.copy(alpha = .08f),
                    modifier = Modifier.size(130.dp).align(Alignment.CenterEnd))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("ОНЛАЙН", "1 248", "● Сервер активен", Modifier.weight(1f))
                StatCard("ВЕРСИЯ", "1.0.0", "Клиент готовится", Modifier.weight(1f))
            }
        }
        item {
            Button(
                onClick = onPlay,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(18.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(8.dp))
                Text("ИГРАТЬ", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
            }
        }
        if (launchMessage.isNotBlank()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = Cyan)
                        Spacer(Modifier.width(10.dp))
                        Text(launchMessage, modifier = Modifier.weight(1f), fontSize = 12.sp, color = TextMuted)
                        IconButton(onClick = onDismissMessage) {
                            Icon(Icons.Default.Close, contentDescription = "Закрыть")
                        }
                    }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ЦЕНТР ПРОЕКТА", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.weight(1f))
                Text("Все разделы", color = Cyan, fontSize = 11.sp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ActionCard("Обновления", "Новая версия клиента", Icons.Default.SystemUpdate, Modifier.weight(1f), onUpdates)
                ActionCard("Новости", "Что нового в проекте", Icons.Default.Article, Modifier.weight(1f), onNews)
            }
        }
        item {
            Text(
                if (username == null) "Войди в профиль, чтобы подготовить аккаунт." else "С возвращением, $username!",
                color = TextMuted, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, caption: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(15.dp)) {
            Text(title, color = TextMuted, fontSize = 10.sp, letterSpacing = 1.sp)
            Spacer(Modifier.height(8.dp))
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text(caption, color = Cyan, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector,
                       modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(15.dp)) {
            Icon(icon, contentDescription = null, tint = Accent, modifier = Modifier.size(25.dp))
            Spacer(Modifier.height(12.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = TextMuted, fontSize = 10.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun ColumnScope.NewsPage() {
    LazyColumn(
        Modifier.fillMaxWidth().weight(1f),
        contentPadding = PaddingValues(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { PageTitle("Новости проекта", "СЛЕДИ ЗА СОБЫТИЯМИ") }
        item { NewsCard("19 ОКТЯБРЯ 2026", "NOVA RP открывает двери", "Мы готовим запуск проекта. Следи за обновлениями лаунчера и новостями команды.", "НОВОСТЬ") }
        item { NewsCard("СКОРО", "Первое крупное обновление", "В этом разделе появятся заметки о версиях, событиях и изменениях игрового клиента.", "В РАЗРАБОТКЕ") }
        item { Text("Демонстрационные новости. Подключи API проекта, чтобы получать реальные публикации.", color = TextMuted, fontSize = 11.sp) }
    }
}

@Composable
private fun NewsCard(date: String, title: String, description: String, tag: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(17.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(date, color = TextMuted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                Surface(color = Accent.copy(alpha = .18f), shape = RoundedCornerShape(50)) {
                    Text(tag, color = Color(0xFFB8A9FF), fontSize = 9.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(7.dp))
            Text(description, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
        }
    }
}

@Composable
private fun ColumnScope.UpdatesPage(progress: Float, updating: Boolean, onUpdate: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().weight(1f).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        PageTitle("Обновления", "ВСЕГДА АКТУАЛЬНАЯ ВЕРСИЯ")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(20.dp)) {
                Icon(Icons.Default.CloudDownload, contentDescription = null, tint = Cyan, modifier = Modifier.size(35.dp))
                Spacer(Modifier.height(12.dp))
                Text("NOVA Client", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                Text("Установленная версия: 1.0.0", color = TextMuted, fontSize = 12.sp)
                Spacer(Modifier.height(18.dp))
                if (updating || progress > 0f) {
                    LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(7.dp).clip(CircleShape))
                    Spacer(Modifier.height(8.dp))
                    Text(if (updating) "Подготовка обновления… ${(progress * 100).toInt()}%" else "Демонстрация завершена",
                        color = TextMuted, fontSize = 11.sp)
                } else {
                    Text("Клиент готов к проверке обновлений.", color = TextMuted, fontSize = 12.sp)
                }
                Spacer(Modifier.height(16.dp))
                Button(onClick = onUpdate, enabled = !updating, modifier = Modifier.fillMaxWidth()) {
                    Text(if (updating) "ПРОВЕРКА…" else "ПРОВЕРИТЬ ОБНОВЛЕНИЯ")
                }
            }
        }
        Text("Сейчас используется демонстрационный прогресс. Реальное обновление подключается через HTTPS-сервер и проверку контрольных сумм файлов.",
            color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun ColumnScope.SettingsPage(
    music: Boolean, onMusic: (Boolean) -> Unit,
    highGraphics: Boolean, onGraphics: (Boolean) -> Unit,
    notifications: Boolean, onNotifications: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxWidth().weight(1f).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        PageTitle("Настройки", "НАСТРОЙ ЛАУНЧЕР ПОД СЕБЯ")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column {
                SettingRow("Музыка лаунчера", "Фоновое сопровождение", music, onMusic)
                HorizontalDivider(color = Background)
                SettingRow("Высокая графика", "Рекомендуется для мощных устройств", highGraphics, onGraphics)
                HorizontalDivider(color = Background)
                SettingRow("Уведомления", "Новости и обновления", notifications, onNotifications)
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("О приложении", fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                Text("NOVA RP Launcher • версия 1.0.0", color = TextMuted, fontSize = 12.sp)
                Text("Параметры пока хранятся только в текущем сеансе.", color = TextMuted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingRow(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Medium, fontSize = 14.sp)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = TextMuted, fontSize = 10.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun PageTitle(title: String, subtitle: String) {
    Column {
        Text(title, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, fontSize = 10.sp, color = Cyan, letterSpacing = 1.5.sp)
    }
}

@Composable
private fun BottomBar(selected: String, onSelect: (String) -> Unit) {
    val items = listOf(
        Triple("Главная", Icons.Default.Home, "Главная"),
        Triple("Новости", Icons.Default.Article, "Новости"),
        Triple("Обновления", Icons.Default.CloudDownload, "Обновления"),
        Triple("Настройки", Icons.Default.Settings, "Настройки")
    )
    NavigationBar(containerColor = Color(0xFF0D1018), contentColor = TextMain) {
        items.forEach { (label, icon, route) ->
            NavigationBarItem(
                selected = selected == route,
                onClick = { onSelect(route) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label, fontSize = 9.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Cyan,
                    selectedTextColor = Cyan,
                    indicatorColor = Accent.copy(alpha = .20f),
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                )
            )
        }
    }
}

@Composable
private fun LoginDialog(
    username: String,
    onUsername: (String) -> Unit,
    onDismiss: () -> Unit,
    onLogin: () -> Unit
) {
    var password by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(if (register) "Создать аккаунт" else "Вход в NOVA RP", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("Демо-форма интерфейса. Пока аккаунт не проверяется сервером.", color = TextMuted, fontSize = 12.sp)
                OutlinedTextField(value = username, onValueChange = onUsername, label = { Text("Имя пользователя") }, singleLine = true)
                OutlinedTextField(value = password, onValueChange = { password = it },
                    label = { Text("Пароль (демо)") }, singleLine = true)
                TextButton(onClick = { register = !register }) {
                    Text(if (register) "Уже есть аккаунт? Войти" else "Создать аккаунт")
                }
            }
        },
        confirmButton = {
            Button(onClick = onLogin, enabled = username.trim().isNotEmpty()) {
                Text(if (register) "ЗАРЕГИСТРИРОВАТЬСЯ" else "ВОЙТИ")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun LoadingScreen() {
    var dots by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(400)
            dots = (dots + 1) % 4
        }
    }
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF171331), Background))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(92.dp).clip(RoundedCornerShape(28.dp))
                    .background(Brush.linearGradient(listOf(Accent, Cyan))),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null, tint = Color.White, modifier = Modifier.size(55.dp))
            }
            Spacer(Modifier.height(24.dp))
            Text("NOVA RP", fontSize = 28.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
            Spacer(Modifier.height(10.dp))
            Text("ПОДГОТОВКА К ЗАПУСКУ" + ".".repeat(dots), color = Cyan, fontSize = 11.sp, letterSpacing = 1.5.sp)
            Spacer(Modifier.height(25.dp))
            CircularProgressIndicator(color = Accent, strokeWidth = 3.dp, modifier = Modifier.size(30.dp))
        }
    }
}
